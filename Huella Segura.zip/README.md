
  # Huella Segura

  This is a code bundle for Huella Segura. The original project is available at https://www.figma.com/design/S9v05gR0QGINQi2uZbTIgN/Huella-Segura.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  