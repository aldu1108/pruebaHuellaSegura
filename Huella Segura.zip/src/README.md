# PetCare - Aplicación de Cuidado de Mascotas

## Descripción
PetCare es una aplicación web PWA desarrollada en **JavaScript vanilla, HTML5 y CSS3** para el cuidado integral de mascotas. No utiliza React ni ningún framework.

## Características Principales

### 🎨 Paleta de Colores Específica
- **Header**: #FAE5A1 (amarillo claro)
- **Menú hamburguesa líneas**: #3D291D (marrón oscuro)
- **Menú hamburguesa fondo**: #B58568 (marrón medio)
- **Navegación inferior**: #EE9444 (naranja)
- **Botones**: #E55826 (naranja intenso) estilo Instagram

### 📱 6 Secciones Principales
1. **🏠 Página Principal** - Dashboard con recordatorios y citas
2. **🐕 Mis Mascotas** - Gestión de perfiles de mascotas
3. **🔍 Mascotas Perdidas** - Reportes y búsqueda de mascotas
4. **🛒 Tienda** - Productos y servicios para mascotas
5. **👥 Comunidad** - Feed social y eventos
6. **🏥 Veterinario** - Citas médicas y servicios veterinarios

### ⚡ Funcionalidades
- ✅ Navegación con menú hamburguesa lateral
- ✅ Barra de búsqueda funcional
- ✅ Navegación inferior tipo Instagram
- ✅ Dashboard con estadísticas y recordatorios
- ✅ Feed de comunidad con interacciones
- ✅ Diseño responsive y moderno
- ✅ PWA (Progressive Web App)
- ✅ Service Worker para funcionalidad offline

## Estructura de Archivos

```
/
├── index.html              # Punto de entrada principal
├── js/
│   └── app.js              # Lógica principal de la aplicación
├── styles/
│   └── globals.css         # Estilos CSS con variables de color
├── manifest.json           # Configuración PWA
├── sw.js                   # Service Worker
└── README.md               # Documentación
```

## Tecnologías Utilizadas
- **HTML5** - Estructura semántica
- **CSS3** - Estilos con variables CSS y Tailwind CDN
- **JavaScript Vanilla** - Lógica de aplicación sin frameworks
- **PWA** - Progressive Web App con Service Worker
- **Tailwind CSS** - Framework de utilidades CSS (CDN)

## Cómo Ejecutar
1. Abrir `index.html` en un navegador web
2. O servir desde un servidor local:
   ```bash
   # Con Python
   python -m http.server 8000
   
   # Con Node.js
   npx serve .
   ```

## Características PWA
- ✅ Instalable en dispositivos móviles
- ✅ Funciona offline
- ✅ Icono de aplicación personalizado
- ✅ Splash screen
- ✅ Cache inteligente

## Responsive Design
- ✅ Optimizado para móviles (mobile-first)
- ✅ Tablet y desktop compatible
- ✅ Navegación adaptativa

## Notas Importantes
- **Sin React**: Desarrollado completamente en JavaScript vanilla
- **Sin TypeScript**: Solo JavaScript ES6+
- **Sin Node.js**: No requiere build process
- **Compatibilidad**: Funciona en navegadores modernos
- **Performance**: Optimizado para carga rápida

---

**PetCare** - Tu aplicación integral para el cuidado de mascotas 🐾