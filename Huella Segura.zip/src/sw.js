// Service Worker para PetCare PWA
const CACHE_NAME = 'petcare-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/js/app.js',
  '/styles/globals.css',
  '/manifest.json',
  'https://cdn.tailwindcss.com'
];

// Instalar SW
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Cache abierto');
        return cache.addAll(urlsToCache);
      })
  );
});

// Interceptar requests
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Devolver del cache si existe
        if (response) {
          return response;
        }
        
        // Si no, hacer fetch
        return fetch(event.request).then(
          (response) => {
            // Verificar si es una respuesta válida
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // Clonar respuesta
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return response;
          }
        );
      })
      .catch(() => {
        // Si falla todo, mostrar página offline básica
        return new Response(`
          <!DOCTYPE html>
          <html>
          <head>
            <title>PetCare - Sin conexión</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
              body { 
                font-family: Arial, sans-serif; 
                text-align: center; 
                padding: 50px; 
                background-color: #f9fafb;
              }
              .offline { 
                background-color: #FAE5A1; 
                padding: 20px; 
                border-radius: 10px; 
                display: inline-block;
              }
            </style>
          </head>
          <body>
            <div class="offline">
              <h1>🐾 PetCare</h1>
              <p>Sin conexión a internet</p>
              <p>Verifica tu conexión e intenta nuevamente</p>
            </div>
          </body>
          </html>
        `, {
          headers: { 'Content-Type': 'text/html' }
        });
      })
  );
});

// Activar SW
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Eliminando cache antiguo:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});