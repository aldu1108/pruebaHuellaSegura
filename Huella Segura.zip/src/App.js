// Este archivo se mantiene para compatibilidad, pero la funcionalidad está en /js/app.js
console.log('PetCare - Aplicación JavaScript Vanilla iniciada');
console.log('La funcionalidad principal está en /js/app.js');